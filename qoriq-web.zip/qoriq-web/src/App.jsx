import React from 'react'
import './index.css'

// TODO: Replace this placeholder with the full QoriqLanding component from your canvas.
// Just copy the entire component content and paste here.

export default function App() {
  return (
    <div className="text-white p-10">
      <h1 className="text-4xl font-bold">Qoriq Web is ready.</h1>
      <p className="mt-4 text-white/70">
        Now paste your QoriqLanding component from the canvas into App.jsx to render the real UI.
      </p>
    </div>
  )
}
